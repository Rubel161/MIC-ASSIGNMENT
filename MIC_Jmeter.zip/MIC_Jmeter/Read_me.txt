___ This file is created with respect to the Jmeter test performed on https://mic.gov.in/  ___



Here we have simulated the situation with 50 thread_groups with ramp up period 5 , 
which means that in 5 secs 50 users are accessing the mic website and what was its performance in this situation.


 Observation:
 1) No of API request send on page reload action is quite high approx 250 API are hitting.
 2) Response size of API is also too high more than 50 KB.
 3) Page load time is also too high.
 4) Browser cache is mot managed effectively.
 5) Architecture used for the website could be more optimized in order to improve the performance
 
 
 
 NOTE: 
 1) Some time SSL handshake authentication error is observed while hitting the request for further debugging we need more info on types and format used in API 
 used by this website.
 2) Once we have the token or any other authenticated parameter which allows these type of users to access the website we can do more thorough performance testing.